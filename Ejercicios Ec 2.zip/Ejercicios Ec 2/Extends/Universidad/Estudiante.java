// Modifique la definicion de la clase para realizar la herencia 
public class Estudiante extends Persona
{
    // Defina el atributo privado 'carrera' (String)
    private String carrera;
    
    // Implemente el constructor
    /**
     * El constructor debe recibir nombre, dni y carrera.
     * Debe inicializar todo correctamente.
     */
    public Estudiante(String nombre, int dni, String carrera)
    {
        //TODO : Implementar
        super(nombre,dni);
        this.carrera  = carrera;
        
    }

    public String getCarrera()
    {
        // TODO: Implementar
        return carrera;
    }
}