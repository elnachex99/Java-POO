// ESTA CLASE YA ESTA LISTA
public class Computadora
{
    private String procesador;
    private int ram;

    public Computadora(String procesador, int ram)
    {
        this.procesador = procesador;
        this.ram = ram;
    }
}