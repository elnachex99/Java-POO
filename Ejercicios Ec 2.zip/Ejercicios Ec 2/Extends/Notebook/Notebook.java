// Modifique la definicion de la clase para realizar la herencia 
public class Notebook extends Computadora
{
    // Defina el atributo privado 'peso' (double)
    private double peso;
    
    // Implemente el constructor
    /**
     * Constructor de Notebook.
     * Recibe: procesador (String), ram (int) y peso (double).
     */
    public Notebook(String procesador, int ram, double peso)
    {
        super(procesador,ram);
        this.peso = peso;
    }

    public double getPeso()
    {
        return peso;
    }
}