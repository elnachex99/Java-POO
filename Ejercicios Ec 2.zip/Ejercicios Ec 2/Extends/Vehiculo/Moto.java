// Modifique la definición para realizar la herencia
public class Moto extends Vehiculo {

    // Sin atributos nuevos

    /**
     * Constructor de Moto.
     * Solo recibe la marca.
     * PISTA: Al llamar a super(), el primer parámetro es la marca
     * y el segundo (cantidadRuedas) debe ser siempre 2.
     */
    public Moto(String marca) {
         super(marca,2);
    }
}