// ESTA CLASE YA ESTÁ LISTA (NO TOCAR)
public class Vehiculo {
    private String marca;
    private int cantidadRuedas;

    public Vehiculo(String marca, int cantidadRuedas) {
        this.marca = marca;
        this.cantidadRuedas = cantidadRuedas;
    }
    
    public int getRuedas() { return cantidadRuedas; }
}