// Modifique la definición para realizar la herencia
public class Gerente extends Empleado {
    
    // 1. Defina el atributo privado 'departamento' (String)
    private String departamento;

    /**
     * Constructor.
     * Debe recibir nombre, sueldo y departamento.
     * PISTA: Pásale nombre y sueldo al padre con super().
     */
    public Gerente(String nombre, double sueldo, String departamento) {
        super(nombre, sueldo); // Mandamos esto al padre
        this.departamento = departamento; // Nos guardamos esto
    }

    public String getDepartamento() {
        return this.departamento;
    }
}