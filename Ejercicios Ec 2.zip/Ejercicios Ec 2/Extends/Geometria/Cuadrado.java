// Modifique la definicion de la clase para realizar la herencia 
public class Cuadrado extends Rectangulo
{
    // Sin atributos nuevos
    
    // Implemente el constructor
    /**
     * Constructor de Cuadrado.
     * Solo recibe la medida del 'lado' (double).
     * RECORDATORIO: Un cuadrado es un rectangulo donde base y altura son iguales.
     */
    public Cuadrado(double lado)
    {
        // TODO: Implementar llamada a super
        super(lado,lado);
    }
}
