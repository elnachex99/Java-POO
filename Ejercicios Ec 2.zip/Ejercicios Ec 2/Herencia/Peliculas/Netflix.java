// --- TU MISIÓN ESTÁ AQUÍ ---
import java.util.ArrayList;

public class Netflix {
    
    ArrayList<Titulo> catalogo;
    
    public Netflix() {
        catalogo = new ArrayList<>();
    }
    
    public void agregarTitulo(Titulo t) {
        catalogo.add(t);
    }
    
    /**
     * Recorre el catálogo.
     * Si el título es de tipo PELICULA:
     * 1. Lo convierte (castea) a Pelicula.
     * 2. Lo agrega a una lista nueva.
     * 3. Retorna esa lista.
     */
    public ArrayList<Pelicula> getSoloPeliculas() {
        // TODO: Implementar
        
        ArrayList<Pelicula> peliculas = new ArrayList<>();
        for(Titulo t : catalogo){
            if(t.getTipo().equals(Tipo.PELICULA)){
                peliculas.add((Pelicula) t);
            }
        }
        return peliculas; 
    }
}