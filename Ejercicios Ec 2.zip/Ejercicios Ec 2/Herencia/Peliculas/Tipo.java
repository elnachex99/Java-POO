public enum Tipo {
    PELICULA, SERIE, DOCUMENTAL;
}