// Clase Hija
public class Pelicula extends Titulo {
    public Pelicula() {
        super(Tipo.PELICULA);
    }
}