// Clase Padre
public class Titulo {
    private Tipo tipo;
    
    public Titulo(Tipo tipo) {
        this.tipo = tipo;
    }
    
    public Tipo getTipo() {
        return tipo;
    }
}