import java.util.ArrayList;

public class Carrito {
    
    ArrayList<Producto> items;
    
    public Carrito() {
        items = new ArrayList<>();
    }
    
    public void agregar(Producto p) {
        items.add(p);
    }
    
    /**
     * Filtra y retorna solo los productos electrónicos.
     */
    public ArrayList<Electronico> getElectronicos() {
        // TODO: Implementar
        
        ArrayList<Electronico> electronico = new ArrayList<>();
        for(Producto p : items){
            if(p.getCategoria().equals(Categoria.ELECTRONICO)){
                electronico.add((Electronico) p);
            }
        }
        return electronico;
    }
}