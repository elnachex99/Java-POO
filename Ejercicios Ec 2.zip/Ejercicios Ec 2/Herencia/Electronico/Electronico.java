public class Electronico extends Producto {
    public Electronico() {
        super(Categoria.ELECTRONICO);
    }
}