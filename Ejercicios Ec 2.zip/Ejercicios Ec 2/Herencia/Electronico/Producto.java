public class Producto {
    private Categoria cat;
    
    public Producto(Categoria cat) { this.cat = cat; }
    
    public Categoria getCategoria() { return cat; }
}