public enum Categoria {
    ALIMENTO, ELECTRONICO, ROPA;
}