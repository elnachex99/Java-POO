import java.util.ArrayList;
public class Hospital {
    ArrayList<Persona> personas;
    public Hospital() {
        personas = new ArrayList<>();
    }

    public void ingresarPersona(Persona p) {

        personas.add(p);

    }

    /**
     * Retorna una lista que contenga ÚNICAMENTE a los objetos
     * que tengan el Rol.MEDICO, convertidos a la clase Medico.
     */
    public ArrayList<Medico> getStaffMedico() {
        // TODO: Implementar
        ArrayList<Medico> medicos = new ArrayList<>();
        for(Persona p : personas){
            if(p.getRol().equals(Rol.MEDICO)){
                medicos.add((Medico) p);
            }
        }
        return medicos;
    }
}