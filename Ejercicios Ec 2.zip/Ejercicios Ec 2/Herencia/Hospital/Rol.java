public enum Rol {
    MEDICO, PACIENTE, ENFERMERO;
}