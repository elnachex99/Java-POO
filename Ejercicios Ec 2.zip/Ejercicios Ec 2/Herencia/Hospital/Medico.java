public class Medico extends Persona {
    public Medico() {
        super(Rol.MEDICO);
    }
}