public class Persona {
    private Rol rol;
    
    public Persona(Rol rol) {
        this.rol = rol;
    }
    
    public Rol getRol() { return rol; }
}