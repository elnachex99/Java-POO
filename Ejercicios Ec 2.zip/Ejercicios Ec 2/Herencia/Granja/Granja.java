// --- TU MISIÓN ESTÁ AQUÍ ---
import java.util.ArrayList;

public class Granja {
    
    ArrayList<Animal> animales;
    
    public Granja() {
        animales = new ArrayList<>();
    }
    
    public void agregarAnimal(Animal a) {
        animales.add(a);
    }
    
    /**
     * Retorna una lista que contenga SOLO a las vacas.
     * Recuerda:
     * La lista de retorno debe ser <Vaca>
     */
    public ArrayList<Vaca> getVacas() {
        // TODO: Implementar
        ArrayList<Vaca> vacas = new ArrayList<>();
        for(Animal a : animales){
            if(a.getTipo().equals(Tipo.VACA)){
                vacas.add((Vaca) a);
            }
        }
        return vacas; 
    }
}