public enum Tipo {
    VACA, CERDO, GALLINA;
}