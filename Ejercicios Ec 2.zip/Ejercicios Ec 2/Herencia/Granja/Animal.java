public class Animal {
    private Tipo tipo;
    
    public Animal(Tipo tipo) { this.tipo = tipo; }
    
    public Tipo getTipo() { return tipo; }
}