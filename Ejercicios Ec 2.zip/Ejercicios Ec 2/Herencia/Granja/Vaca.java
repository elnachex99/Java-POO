public class Vaca extends Animal {
    public Vaca() {
        super(Tipo.VACA);
    }
}