import java.util.HashMap;

public class Tienda {
    
    HashMap<Talle, Integer> stock;
    
    /**
     * Inicializa el mapa 'stock'.
     * Debe recorrer todos los Talles del enum y asignarles
     * una cantidad inicial de 0 (cero) unidades a cada uno.
     **/
    public Tienda() {
        this.stock = new HashMap<>();
        for(Talle t  : Talle.values()){
            stock.put(t,0);
        }
        
    }
    
    /**
     * Actualiza la cantidad de prendas para un talle específico.
     * (Sobreescribe el valor anterior con el nuevo 'cantidad').
     **/
    public void actualizarStock(Talle t, int cantidad) {
            stock.put(t,cantidad);
    }
    
    /**
     * Retorna cuántas prendas hay de ese talle.
     **/
    public int getCantidad(Talle t) {
        return stock.get(t);     
    }
    
    /**
     * Retorna TRUE si la cantidad de ese talle es mayor a 0.
     * Retorna FALSE si es 0 (o menos).
     **/
    public boolean hayStock(Talle t) {
        int cantidadActual = stock.get(t);
        if(cantidadActual > 0){
            return true;
        }
        return false; // Borra y completa la lógica
    }
}