public enum Talle{
    XXL ,XL , L , M , S , XS;
}