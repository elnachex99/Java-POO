import java.util.HashMap;

public class Corralon {
    
    private HashMap<Material, Integer> inventario;
    
    /**
     * Inicializa el inventario.
     * Pone todos los materiales en 0.
     **/
    public Corralon() {
        this.inventario = new HashMap<>();
        for(Material  m : Material.values()){
            inventario.put(m,0);
        }
    }
    
    /**
     * Ingresa mercadería al corralón.
     * Suma la 'cantidad' recibida al stock actual de ese material.
     **/
    public void recibirPedido(Material m, int cantidad) {
        int cantidadActual = inventario.get(m);
        int suma = cantidadActual + cantidad;
        inventario.put(m,suma);
    }
    
    /**
     * Intenta vender una cantidad de material.
     * 1. Verifica si hay suficiente stock (stock actual >= cantidad pedida).
     * 2. Si HAY: resta la cantidad, actualiza el mapa y retorna TRUE.
     * 3. Si NO HAY: no hace nada y retorna FALSE.
     **/
    public boolean venderMaterial(Material m, int cantidad) {
        int stockActual = inventario.get(m);
        if(stockActual >= cantidad){
            stockActual = stockActual - cantidad;
            inventario.put(m,stockActual);
            return true;
        }
        return false; 
    }
    
    /**
     * Retorna la cantidad de unidades que hay de ese material.
     **/
    public int getStockDe(Material m) {
        return inventario.get(m);
    }
}