public enum Material {
    CEMENTO, ARENA, CAL, LADRILLO, HIERRO;
}