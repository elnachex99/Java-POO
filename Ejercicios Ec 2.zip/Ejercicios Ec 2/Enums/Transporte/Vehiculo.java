public enum Vehiculo {
    AUTO, MOTO, CAMION, CAMIONETA, COLECTIVO;
}