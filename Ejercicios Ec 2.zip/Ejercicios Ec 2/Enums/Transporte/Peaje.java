import java.util.HashMap;
public class Peaje {
    
    private HashMap<Vehiculo, Integer> contadorVehiculos;
    
    /**
     * Inicializa el mapa.
     * Debe inicializar la instancia del HashMap y
     * cargar todos los tipos de Vehiculo con cantidad 0.
     **/
    public Peaje() {
        this.contadorVehiculos = new HashMap<>();
        
        for(Vehiculo v : Vehiculo.values()){
            contadorVehiculos.put(v,0);
        }
        
    }
    
    /**
     * Registra que acaba de pasar un vehiculo.
     * Incrementa en 1 la cantidad acumulada para ese tipo de vehiculo.
     **/
    public void registrarPaso(Vehiculo v) {
        int contadorActual = contadorVehiculos.get(v);
        contadorActual = contadorActual + 1;
        contadorVehiculos.put(v,contadorActual);  
    }
    
    /**
     * Retorna la cantidad exacta de vehículos que pasaron de ese tipo.
     **/
    public int getCantidadPorTipo(Vehiculo v) {
        return contadorVehiculos.get(v); 
    }
    
    /**
     * Retorna la suma total de TODOS los vehículos que pasaron hoy
     * (sin importar el tipo).
     **/
    public int getTotalVehiculos() {
        int sumador = 0;
        for(int v : contadorVehiculos.values()){
            sumador = sumador + v;
        }
        return sumador;
    }

    /**
     * Retorna true si pasaron más de 100 vehículos de ese tipo específico.
     * Retorna false en caso contrario.
     **/
    public boolean esHoraPicoPara(Vehiculo v) {
        int contadorMasCien = contadorVehiculos.get(v);
        if(contadorMasCien > 100){
            return true;
        }
        return false;
    }
}