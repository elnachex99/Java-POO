public enum Partido{
    ROJO, AZUL, VERDE, BLANCO;
}