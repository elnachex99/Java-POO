import java.util.HashMap;

public class Urna {
    
    private HashMap<Partido, Integer> conteo;
    
    /**
     * Inicializa la urna.
     * Recorre los partidos y pone a todos en 0.
     **/
    public Urna() {
        this.conteo = new HashMap<>();
        
        for(Partido p : Partido.values()){
            conteo.put(p,0);
        }
    }
    
    /**
     * Suma 1 voto al partido recibido.
     * PISTA: 
     * 1. Obtén cuantos votos tiene AHORA usando .get(p)
     * 2. Súmale 1 a ese número.
     * 3. Guarda el nuevo número usando .put(p, nuevoValor)
     **/
    public void recibirVoto(Partido p) {
        int cantidad = conteo.get(p);
        cantidad = cantidad + 1;
        conteo.put(p,cantidad);
        
    }
    
    /**
     * Retorna cuántos votos tiene un partido específico.
     * (Directo, sin bucles).
     **/
    public int getVotosDe(Partido p) {
        return conteo.get(p);
    }
    
    /**
     * Retorna la suma total de votos en la urna.
     * PISTA: Aquí sí necesitas un bucle 'for', pero usa .values()
     * porque solo quieres sumar los números.
     **/
    public int getTotalVotos() {
        int sumador = 0;
        for(int p : conteo.values()){
            sumador = sumador + p;
        }
        return sumador; // Complétalo
    }
}