public enum Bebida{
    JUGO ,CAFE ,CERVEZA ,TRAGO , GASEOSA ;
}