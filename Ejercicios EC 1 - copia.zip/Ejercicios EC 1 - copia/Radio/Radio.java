public class Radio {
    // El volumen actual de la radio (0 a 100)
    private Integer volumen;

    public Radio() {
        // TODO: Inicializar el volumen en 0 (silencio)
        this.volumen = 0;
    }

    /**
     * Intenta cambiar el volumen.
     * REGLAS:
     * 1. El nivel debe estar entre 0 y 100 (inclusive).
     * 2. Si es válido, actualiza el atributo y retorna true.
     * 3. Si no es válido, no hace nada y retorna false.
     * * @param nivel El nuevo nivel de volumen deseado.
     */
    public boolean setVolumen(Integer nivel) {
        // TODO: Implementar sin pistas
        if(nivel >= 0 && nivel <= 100){
            this.volumen = nivel;
            return true;
        }
        else{
            return false;
        }
    }

    public Integer getVolumen() {
        // TODO: Implementar getter
        return this.volumen;
    }
}