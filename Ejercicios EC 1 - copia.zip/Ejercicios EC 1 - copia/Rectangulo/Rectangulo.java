public class Rectangulo {
    public String identificador;

    /**
     * Si el argumento id es distinto de null:
     * 1. Setea el identificador.
     * 2. IMPORTANTE: Debe remover cualquier espacio inicial Y convertirlo a minúsculas.
     * * Si el argumento id es null:
     * - Ignora el valor y no hace nada.
     * * @param id El nuevo identificador
     */
    public void setIdentificador(String id) {
        // TODO: Implementar lógica de validación y transformación de texto
        if(id == null){
            return;
        }
        else{
            this.identificador = id.trim().toLowerCase();
            return;
        }
        
    }

    /**
     * Retorna el valor del identificador.
     */
    public String getIdentificador() {
        // TODO: Implementar return
        return identificador;
    }
}