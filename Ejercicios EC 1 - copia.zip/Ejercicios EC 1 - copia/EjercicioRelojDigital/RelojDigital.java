public class RelojDigital {
    private Integer hora;
    private Integer minuto;

    public RelojDigital() {
        // Inicia a las 00:00
        hora = 0;
        minuto = 0;
    }

    /**
     * Configura el horario.
     * Validaciones requeridas:
     * - La hora debe estar entre 0 y 23.
     * - Los minutos deben estar entre 0 y 59.
     * Si alguno no es válido, NO se modifica nada del reloj.
     */
    public void setTiempo(Integer nuevaHora, Integer nuevoMinuto) {
        // TODO: Implementar validación y asignación
        if((nuevaHora >= 0) && (nuevaHora <= 23)){
            this.hora = nuevaHora;
        }
        if((nuevoMinuto >= 0) && (nuevoMinuto <= 59)){
            this.minuto = nuevoMinuto;
        }
    }
    
    /**
     * Devuelve la hora en formato digital estricto "HH:MM".
     * Ejemplos:
     * - Si es 9 y 5, devuelve "09:05"
     * - Si es 23 y 15, devuelve "23:15"
     * - Si es 0 y 0, devuelve "00:00"
     */
    public String getHoraPantalla() {
        String nuevaHora = "";
        String nuevoMinuto = "";
        
        if (hora < 10){
            nuevaHora = "0" + hora;
        }
        else{
            nuevaHora = "" + hora;
        }
        
        if(minuto < 10){
            nuevoMinuto = "0" + minuto;
        }
        else{
            nuevoMinuto = "" + minuto;
        }
        return nuevaHora + ":" + nuevoMinuto;
    }
}