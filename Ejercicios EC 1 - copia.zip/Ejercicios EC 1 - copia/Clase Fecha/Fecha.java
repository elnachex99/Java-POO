public class Fecha {
    Integer dia;
    Integer mes;
    Integer anio;

    /**
     * Construye un objeto Fecha,
     * No modificar el constructor
     */
    Fecha () {
        dia = 1;
        mes = 1;
        anio = 1980;
    }

    /**
     * Configura el día para la fecha.
     * Solo permite valores entre 1 y 30 incluidos
     *
     * @param dia El número de día a setear
     */
    public void setDia(Integer dia) {
        if( dia >= 1 && dia <= 30){
            this.dia = dia;
        }
    }

    /**
     * Devuelve la fecha con el siguiente formato:
     * - 01/01/1980
     * @return Le fecha como un string.
     */
    String getFecha () {
        String textoDia = "";
        String textoMes = "";
        
        if((dia < 10)){
            textoDia = "0" + dia;
        }
        else{
            textoDia = "" + dia;
        }
        
        if (mes < 10) {
            textoMes = "0" + mes;
        } else {
            textoMes = "" + mes;
        }
        return textoDia + "/" + textoMes + "/" + anio;
    }

    /* No modificar los siguientes métodos */
    public Integer getDia() {
        return dia;
    }
}