import java.util.ArrayList;

public class Curso {
    // Lista de notas (del 1 al 10)
    private ArrayList<Integer> notas;

    public Curso() {
        this.notas = new ArrayList<>();
    }

    /**
     * Recorre la lista e imprime en pantalla SOLO las notas aprobadas (>= 6).
     */
    public void mostrarAprobados() {
        for(Integer nota : notas ){
            if (nota >= 6){
                System.out.println(nota);
            }
        }
        // TODO: Escribe el for-each y el if
        // Recuerda el truco: for (Tipo nombre : lista)
        
    }

    /* Método para probar (No tocar) */
    public void agregarNota(Integer n) {
        notas.add(n);
    }
}