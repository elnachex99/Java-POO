public class Casa {
    // La Casa tiene un termostato instalado
    private Termostato termostato;

    public Casa() {
        // TODO: Instala el termostato (usa new...)
        this.termostato = new Termostato();
        /*Si dices this.termostato, le estás diciendo a Java: "Busca la variable que 
        pertenece a ESTA clase, la que está definida arriba del todo como private"*/
    }

    /**
     * Configura la temperatura de la casa y nos dice cuánto gastaremos.
     * @param grados Los grados que quiere el usuario (ej: 24)
     * @return El consumo en watts calculado por el termostato
     */
    public Integer calcularGastoLuz(Integer grados) {
        // TODO:
        // 1. Pásale los 'grados' al termostato (set...)
        // 2. Pídele al termostato el consumo (get...)
        // 3. Devuelve ese valor
        termostato.setTemperatura(grados);
        return termostato.getConsumoWatts();
    }
}