public class Termostato {
    private Integer temperatura;
    private Integer consumo;

    public Termostato() {
        this.temperatura = 0;
        this.consumo = 0;
    }

    public void setTemperatura(Integer nuevaTemp) {
        temperatura = nuevaTemp;
    }

    /**
     * Calcula el consumo en Watts.
     * Fórmula: temperatura multiplicado por 150.
     */
    public Integer getConsumoWatts() {
        consumo = temperatura * 150;
        return consumo; 
    }
}