public class Usuario {
    // La contraseña actual del usuario
    private String password;

    public Usuario(String passwordInicial) {
        this.password = passwordInicial;
    }

    /**
     * Cambia la contraseña del usuario.
     * REGLAS:
     * 1. La nuevaPassword NO puede ser null.
     * 2. La nuevaPassword debe tener MÁS de 6 caracteres (mínimo 7).
     * 3. Si cumple ambas, actualiza el atributo y retorna true.
     * 4. Si no cumple alguna, retorna false y no hace cambios.
     * @param nuevaPassword La contraseña propuesta.
     */
    public boolean cambiarPassword(String nuevaPassword) {
        // TODO: Implementar lógica de seguridad
        if (nuevaPassword == null || nuevaPassword.length() < 7 ){
            return false;
        }
        else{
            this.password = nuevaPassword;
            return true;
        }
    }

    public String getPassword() {
        // TODO: Implementar getter
        return password;
    }
}