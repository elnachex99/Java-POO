import java.util.ArrayList;

public class CajaRegistradora {
    private ArrayList<Double> precios;
    private double precioActual;

    public CajaRegistradora() {
        // TODO: Inicializa la lista 'precios' con new...
        precios = new ArrayList<>();
    }

    /**
     * Recorre la lista, suma todos los precios y devuelve el resultado final.
     */
    public Double calcularTotalCompra() {
        Double total = 0.0;
        // TODO:
        // 1. Haz el for-each (Cuidado: dentro de los picos dice Double)
        for (Double precio : precios){
            total = total + precio;
        }
        // 2. Adentro del bucle: total = total + precioActual;
        
        return total;
    }

    /* Método para probar (No tocar) */
    public void escanearProducto(Double precio) {
        precios.add(precio);
    }
}