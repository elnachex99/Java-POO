import java.util.ArrayList;

public class Numeros {
    private ArrayList<Integer> numeros;

    public Numeros() {
        this.numeros = new ArrayList<>();
    }

    /**
     * Imprime solo los números impares de la lista.
     * Pista: Usa un bucle for-each y el operador módulo (%)
     */
    public void printImpares() {
        // TODO: implemente el método usando la lista interna 'numeros'
        for(Integer n : numeros ){
            if (n % 2 != 0){
                System.out.println(n);
            }
        }
    }

    /* No modificar los siguientes métodos */
    public void addNumeros (ArrayList<Integer> nros) {
        numeros.addAll(nros);
    }

    public ArrayList<Integer> getNumeros() {
        return numeros;
    }
}