import java.util.ArrayList;

public class Analizador {
    private ArrayList<String> palabras;

    public Analizador() {
        palabras = new ArrayList<>();
    }

    public void imprimirGritos() {
        // TODO: Bucle 1 - Imprime cada palabra en MAYÚSCULAS
        // Pista: Define la variable temporal String y usa .toUpperCase()
        for(String palabra : palabras){
            System.out.println(palabra.toUpperCase());
        }
        
    }

    public Integer contarPalabrasLargas() {
        Integer cantidad = 0;
        // TODO: Bucle 2 - Cuenta las palabras con longitud > 5
        // Pista: Usa un if adentro del for
        for(String palabra : palabras){
            if (palabra.length() > 5 ){
                cantidad++;
            }
        }
        return cantidad;
    }

    public void agregar(String p) { palabras.add(p); }
}