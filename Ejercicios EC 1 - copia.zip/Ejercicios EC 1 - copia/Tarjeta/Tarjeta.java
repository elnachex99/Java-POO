public class Tarjeta
{
    public String numero;

    public Tarjeta (String numero)
    {
        this.numero = numero;
    }
    
     /**
     * Si el argumento es distinto de null y valido, setea el numero de tarjeta.
     * Si el argumento es null o invalido, setea el valor en un string vacio "".
     * @param numero El numero de la tarjeta. Es valido cuando tiene 16 caracteres. 
     */
    public void setNumero(String numero)
    {
       if(numero != null && numero.length() == 16){
           this.numero = numero;
       }
       else{
           this.numero = "";
       }
    }
    
    /**
     * Retorna el numero de la tarjeta.
     */
    public String getNumero()
    {
        // TODO: Implemente el metodo
        return numero;
    }
}