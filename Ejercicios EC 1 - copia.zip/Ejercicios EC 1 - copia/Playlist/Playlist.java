import java.util.ArrayList;

public class Playlist {
    private ArrayList<Cancion> lista;

    public Playlist() {
        lista = new ArrayList<>();
        // TODO: Inicializar la lista
    }

    /**
     * Retorna la suma total de segundos de todas las canciones.
     */
    public Integer getDuracionTotal() {
        // TODO: Implementar sin ayuda
        Integer total = 0;
        for (Cancion c : lista){
            total = total + c.getSegundos();
        }
        return total;
    }

    /**
     * Cuenta cuántas canciones duran más de 300 segundos.
     */
    public Integer contarCancionesLargas() {
        // TODO: Implementar sin ayuda
        Integer contador = 0;
        for(Cancion c : lista){
            if(c.getSegundos() > 300){
                contador++;
            }
        }
        return contador;
    }

    public void agregarCancion(Cancion c) { lista.add(c); }
}