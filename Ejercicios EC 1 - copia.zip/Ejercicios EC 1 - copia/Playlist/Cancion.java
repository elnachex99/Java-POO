public class Cancion {
    private String titulo;
    private Integer segundos; // Duración

    public Cancion(String titulo, Integer segundos) {
        this.titulo = titulo;
        this.segundos = segundos;
    }

    public String getTitulo() { return titulo; }
    public Integer getSegundos() { return segundos; }
}