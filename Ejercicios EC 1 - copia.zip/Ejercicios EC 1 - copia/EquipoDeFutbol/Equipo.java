import java.util.ArrayList;

public class Equipo {
    private ArrayList<Jugador> plantel;

    public Equipo() {
        plantel = new ArrayList<>();
        // TODO: Inicializar lista
    }

    /**
     * Calcula y devuelve la edad promedio de todo el plantel.
     * (Suma de edades / cantidad de jugadores)
     * Si la lista está vacía, devolver 0.0
     */
    public Double calcularEdadPromedio() {
        // TODO: Implementar lógica
        
        Double cantidadJugadores = 0.0;
        
        if (plantel.isEmpty()){
               return 0.0;
        }
        
        Double sumaEdades = 0.0;
        
        for(Jugador edad : plantel){
           sumaEdades = sumaEdades + edad.getEdad(); 
           cantidadJugadores++;           
        }
        Double promedio = sumaEdades / cantidadJugadores;
        return promedio;
    }

    /**
     * Devuelve la cantidad de jugadores que son titulares.
     */
    public Integer contarTitulares() {
        Integer contador = 0;
        for(Jugador titulares : plantel){
            if(titulares.esTitular()){
                contador++;
            }
        }
        return contador;
    }

    public void ficharJugador(Jugador j) { plantel.add(j); }
}