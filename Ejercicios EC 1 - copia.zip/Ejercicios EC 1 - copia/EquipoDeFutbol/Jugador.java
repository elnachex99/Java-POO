public class Jugador {
    private String nombre;
    private Integer edad;
    private boolean esTitular;

    public Jugador(String nombre, Integer edad, boolean esTitular) {
        this.nombre = nombre;
        this.edad = edad;
        this.esTitular = esTitular;
    }

    public Integer getEdad() { 
        return edad; 
    }
    public boolean esTitular() { 
        return esTitular; 
    }
}