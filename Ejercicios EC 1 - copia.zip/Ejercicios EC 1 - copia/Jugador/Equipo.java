import java.util.ArrayList;

public class Equipo {
    private ArrayList<Jugador> jugadores;
    private String nombre;

    public Equipo() {
        this.jugadores = new ArrayList<>();
    }

    public void ficharJugador(Jugador j) {
        this.jugadores.add(j);
    }

    /**
     * Busca y retorna el Jugador que haya metido más goles.
     * Si la lista está vacía, retorna null.
     */
    public Jugador obtenerGoleador() {
        // TODO: Algoritmo de búsqueda del máximo sin ayuda
        if (jugadores.isEmpty()){
            return null;
        }
        
        Jugador goleador = null;
        for(Jugador j : jugadores){
            if (goleador == null){
                goleador = j;
            }
            else if(j.getGoles() > goleador.getGoles()){
                goleador = j;
                
            }
        }
        return goleador;
    }
}
