public class Jugador {
    private String nombre;
    private Integer goles;

    public Jugador(String nombre, Integer goles) {
        this.nombre = nombre;
        this.goles = goles;
    }

    public Integer getGoles() {
        return goles;
    }
    
    public String getNombre() {
        return nombre;
    }
}