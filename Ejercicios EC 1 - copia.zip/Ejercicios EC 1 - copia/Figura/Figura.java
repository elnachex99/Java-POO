public class Figura {
    private Rombo rombo;
    private int diagMayor;
    private int diagMenor;

    /**
     * Construye una Figura geométrica con la instancia apropiada
     * y le establece diagonal mayor = 0 y diagonal menor = 0
     */
    public Figura() {
        this.rombo = new Rombo();
    }

    /**
     * Cambia las dimensiones de la figura geométrica y
     * devuelve la superficie.
     * @param diagMayor
     * @param diagMenor
     * @return Superficie del rombo
     */
    public Integer getSuperficieRombo(Integer diagonalMayor, Integer diagonalMenor) {
        // TODO: Implemente el metodo usando el objeto 'rombo'
        rombo.setDiagMayor(diagonalMayor);
        rombo.setDiagMenor(diagonalMenor);
        return rombo.getSuperficie();
    }

    /* No modificar los siguientes métodos */
    public Rombo getRombo() {
        return rombo;
    }
}