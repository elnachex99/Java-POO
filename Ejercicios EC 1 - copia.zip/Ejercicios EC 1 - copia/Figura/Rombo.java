public class Rombo{
    
    //ATRIBUTOS
    private Integer diagMayor;
    private Integer diagMenor;
    
    //CONSTRUCTOR
    public Rombo(){
        diagMayor = 0;
        diagMenor = 0;
    }
    
    //METODOS
    public void setDiagMayor(Integer newDiagMayor){
        diagMayor = newDiagMayor;
    }
    
    public void setDiagMenor(Integer newDiagMenor){
        diagMenor = newDiagMenor;
    }
    
    public Integer getSuperficie(){
        Integer superficie = (diagMayor * diagMenor) / 2;
        return superficie;
    }
}