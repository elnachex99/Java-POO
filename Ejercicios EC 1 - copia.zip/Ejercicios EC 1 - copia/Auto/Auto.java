
public class Auto {
    private Motor motor;

        public Auto() {
        // TODO: Inicializa el motor
        this.motor = new Motor();
    }

    /**
     * Acelera el auto según cuánto pises el pedal.
     * @param presionPedal Un número del 1 al 10.
     * @return La velocidad final que alcanza el motor.
     */
        public Integer conducir(Integer presionPedal) {
        // Paso 1: Convertimos la presión del pie en RPM del motor
        // Fórmula: presionPedal * 1000  (Ej: 5 de presión = 5000 RPM)
        Integer rpmCalculadas = presionPedal * 1000;

        // TODO:
        // 2. Pásale las 'rpmCalculadas' al motor (set...)
        // 3. Devuelve la velocidad que diga el motor (get...)
        motor.setRpm(rpmCalculadas);
        return motor.getVelocidad();
    }
}