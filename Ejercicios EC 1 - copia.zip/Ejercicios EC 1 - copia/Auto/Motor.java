public class Motor {
    private Integer rpm; // Revoluciones por minuto
    private Integer velocidad;

    public Motor() {
        this.rpm = 0 ;
        this.velocidad = 0;
    }

    public void setRpm(Integer nuevasRpm) {
        rpm = nuevasRpm;
    }

    public Integer getVelocidad() {
        // TODO: Retorna (rpm / 20)
        velocidad = (rpm / 20);
        return velocidad;
    }
}