public class Reloj {
    // Variable: hora en formato 24hs (0 a 23)
    private Integer hora;

    public Reloj() {
        this.hora = 0; // Arranca a medianoche
    }

    /**
     * Cambia la hora del reloj.
     * REGLAS:
     * 1. La hora debe estar entre 0 y 23 (inclusive).
     * 2. Si la hora es válida, guarda el valor y retorna true.
     * 3. Si la hora NO es válida (negativa o mayor a 23), la ignora y retorna false.
     * * @param nuevaHora El número de hora a establecer.
     */
    public boolean setHora(Integer nuevaHora) {
        // TODO: Implementar validación y asignación sin ayuda
        if (nuevaHora < 0 || nuevaHora > 23){
            return false;
        }
        else{
            this.hora = nuevaHora;
            return true;
        }
    }

    public Integer getHora() {
        // TODO: Implementar el getter
        return this.hora;
    }
}