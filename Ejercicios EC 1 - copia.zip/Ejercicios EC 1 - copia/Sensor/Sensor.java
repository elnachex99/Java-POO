import java.util.ArrayList;

public class Sensor {
    private ArrayList<Double> temperaturasRegistradas;

    public Sensor() {
        temperaturasRegistradas = new ArrayList<>();
    }

    /**
     * Busca y devuelve la temperatura más alta registrada en la lista.
     * Si la lista está vacía, devuelve 0.0
     */
    public Double obtenerTemperaturaMaxima() {
        Double maxima = -999.0; // Empezamos con un valor muy bajo
        if (temperaturasRegistradas.isEmpty()){
            return 0.0;
        }
        
        for(Double s : temperaturasRegistradas){
            if(s > maxima){
                maxima = s;
            }
        }

        // TODO: Recorrer y encontrar el mayor valor
        return maxima;
    }

    public void registrar(Double t) { temperaturasRegistradas.add(t); }
}