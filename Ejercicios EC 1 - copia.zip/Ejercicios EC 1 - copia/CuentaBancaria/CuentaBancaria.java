public class CuentaBancaria {
    private Double saldo;

    public CuentaBancaria(Double saldo) {
        this.saldo = saldo;
    }

    /**
     * Intenta retirar dinero de la cuenta.
     * REGLAS:
     * 1. El monto a extraer debe ser mayor a 0.
     * 2. El monto a extraer NO puede ser mayor al saldo actual (No hay descubierto).
     * 3. Si pasa las reglas, resta el monto al saldo y retorna true.
     * 4. Si falla, no hace nada y retorna false.
     */
    public boolean extraer(Double monto) {
        // TODO: Tu magia de validación aquí 
        if(monto > 0 && saldo >= monto){
            saldo = saldo - monto;
            return true;
        }
        else{
            return false;
        }
    }

    public Double getSaldo() {
        return saldo;
    }
}