import java.util.ArrayList;

public class Banco {
    private ArrayList<CuentaBancaria> cuentas;
    private Double saldos = 0.0;

    public Banco() {
        cuentas = new ArrayList<>();
        //this.saldos = saldos;
    }

    /**
     * Recorre todas las cuentas y suma sus saldos.
     * @return El dinero total que tiene el banco guardado.
     */
    public Double calcularReservasTotales() {
        // TODO: Tu magia de bucles aquí
        Double saldos = 0.0;
        for (CuentaBancaria cb : cuentas){
            saldos = cb.getSaldo() + saldos;
        }
        return saldos;
    }

    /*public Double getSaldo(){
        return saldos;
    }*/
    
    public void abrirCuenta(CuentaBancaria c) {
        cuentas.add(c);
    }
    
}