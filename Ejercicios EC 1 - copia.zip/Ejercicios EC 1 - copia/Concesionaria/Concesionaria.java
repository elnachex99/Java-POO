import java.util.ArrayList;

public class Concesionaria {
    private ArrayList<Auto> flota;

    public Concesionaria() {
        // Inicializamos la lista vacía
        flota = new ArrayList<>();
    }

    /**
     * Recorre la flota y suma los precios de todos los autos.
     */
    public Double calcularValorStock() {
        Double total = 0.0;
        
        // TODO: Bucle 1 - Suma todos los precios
        // Pista: for (Auto ... : ...)
        // Pista 2: Usa la variable temporal punto getPrecio()
        for(Auto suma : flota){
            total = total + suma.getPrecio();
        }
        
        return total;
    }

    /**
     * Cuenta cuántos autos de la flota son de color "Rojo".
     */
    public Integer contarAutosRojos() {
        Integer cantidadRojos = 0;
        
        // TODO: Bucle 2 - Cuenta los que son color "Rojo"
        // Pista: if ( variableTemporal.getColor().equals("Rojo") )
        for (Auto rojos : flota){
            if(rojos.getColor().equals("Rojo")){
                cantidadRojos++;
            }
        }
        return cantidadRojos;
    }
    
    /* Método para agregar autos a la lista (No tocar) */
    public void agregar(Auto a) { 
        flota.add(a); 
    }
}