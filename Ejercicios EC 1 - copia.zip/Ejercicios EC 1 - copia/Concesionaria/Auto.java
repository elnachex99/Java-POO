public class Auto {
    private String color;
    private Double precio;

    public Auto(String color, Double precio) {
        this.color = color;
        this.precio = precio;
    }

    public String getColor() {
        return color;
    }

    public Double getPrecio() {
        return precio;
    }
}