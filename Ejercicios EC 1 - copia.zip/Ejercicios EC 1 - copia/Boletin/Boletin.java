import java.util.HashMap;

public class Boletin {
    // Mapa: NombreMateria -> Nota
    private HashMap<String, Integer> notas;

    public Boletin() {
        notas = new HashMap<>();
    }

    public Double calcularPromedio() {
        Double suma = 0.0;
        // TODO: Bucle 1 - Suma todas las notas
        // OJO: Es un mapa. Usa notas.values()
        for(Integer n : notas.values()){
            suma = n + suma;
        }
        
        if (notas.size() > 0) {
            return suma / notas.size();
        }
        return 0.0;
    }

    public Integer cantidadAplazos() {
        Integer cont = 0;
        // TODO: Bucle 2 - Cuenta notas menores a 4
        for(Integer n : notas.values()){
            if (n < 4){
                cont++;
            }
        }
        return cont;
    }

    public void ponerNota(String materia, Integer nota) { notas.put(materia, nota); }
}