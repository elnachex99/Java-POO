public class Materia {
    // Variables
    private String profesor;

    // Constructor
    public Materia(String profesor) {
        this.profesor = profesor;
    }

    /**
     * Valida y cambia el nombre del profesor.
     * REGLAS:
     * 1. Si el argumento 'profesor' es distinto de null, setea el valor y retorna true.
     * 2. Si el valor es null O es un String vacío (""), ignora el valor y retorna false.
     * * @param profesor El nombre del nuevo profesor 
     */
    public boolean setProfesor(String profesor) {
        // TODO: Implementar la lógica del if/else
        if(profesor.equals(null) || profesor.equals("")){
            return false;
        }else{
            this.profesor = profesor;
            return true;
        }
    }

    /**
     * Retorna el nombre del profesor actual.
     */
    public String getProfesor() {
        // TODO: Implementar el return
        return profesor;
    }
}