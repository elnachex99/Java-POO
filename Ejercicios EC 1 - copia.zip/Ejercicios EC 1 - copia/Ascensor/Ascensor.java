public class Ascensor {
    private Integer pisoActual;
    private Integer pisoMaximo;
    private Integer pisoMinimo;

    /**
     * Constructor. El ascensor empieza siempre en el piso 0 (Planta Baja).
     * El edificio tiene pisos del -2 (sótano) al 10.
     */
    public Ascensor() {
        pisoActual = 0;  //planta baja
        pisoMinimo = -2; // sotano
        pisoMaximo = 10; // techo
    }

    /**
     * Sube un piso si es posible.
     * Lógica: Solo puede subir si NO ha llegado al pisoMaximo.
     * Si ya está en el piso 10 y llaman a subir, se queda en el 10.
     */
    public void subir() {
        // TODO: Implementar lógica para subir sin pasarse del techo  
            if(pisoActual != 10){
            pisoActual++;  
            }   
        }


    /**
     * Baja un piso si es posible.
     * Lógica: Solo puede bajar si NO ha llegado al pisoMinimo.
     * Si ya está en el -2 y llaman a bajar, se queda en el -2.
     */
    public void bajar() {
        // TODO: Implementar lógica para bajar sin pasarse del sótano
            if(pisoActual != -2 ){
                pisoActual--;
            }
        }

    /**
     * Devuelve un mensaje de estado.
     * - Si está en planta baja (0): "Planta Baja"
     * - Si es negativo: "Sótano X"
     * - Si es positivo: "Piso X"
     */
    public String getInfoPiso() {
        String estadoActual = "";
        if (pisoActual == 0){
            estadoActual = "Planta Baja";
        }
        if (pisoActual < 0){
            estadoActual = "Sotano " + pisoActual;
        }
        if (pisoActual > 0) {
            estadoActual = "Piso " + pisoActual;
        }
        return estadoActual;
    }
}