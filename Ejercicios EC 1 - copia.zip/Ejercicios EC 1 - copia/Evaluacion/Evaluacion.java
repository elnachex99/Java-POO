import java.util.HashMap;

public class Evaluacion {
    // Un mapa para guardar: Nombre del Dueño (String) -> Su Bicicleta (Objeto)
    public HashMap<String, Bicicleta> clientes;

    /**
     * Constructor: Inicializa el mapa
     */
    public Evaluacion() {
        this.clientes = new HashMap<String,Bicicleta>();
        // TODO: Inicializa la variable 'clientes' con un new HashMap...
    }

    /**
     * Recorre todas las bicicletas de los clientes y las parcha.
     * Pista: Usa un for-each sobre los VALORES del mapa.
     */
    public void parcharTodas() {
        // TODO: Implementar el bucle for-each
        // 1. Define el tipo (Bicicleta)
        // 2. Ponle un nombre temporal (bici)
        // 3. Usa la colección correcta ( clientes.values() )
        // 4. Llama al método parchar()
    }
}