public class Microondas {
    // Variable: Nivel de potencia (1 a 10)
    private Integer potencia;

    public Microondas() {
        this.potencia = 1; // Potencia mínima por defecto
    }

    /**
     * Configura la potencia del microondas.
     * @param nuevaPotencia El valor a establecer (debe estar entre 1 y 10)
     */
    public boolean setPotencia(Integer nuevaPotencia) {
        // TODO: Implementar sin ayuda
        if(nuevaPotencia < 1 || nuevaPotencia > 10){
            return false;
        }
        else{
            this.potencia = nuevaPotencia;
            return true;
        }
    }

    public Integer getPotencia() {
        // TODO: Implementar getter
        return potencia;
    }
}