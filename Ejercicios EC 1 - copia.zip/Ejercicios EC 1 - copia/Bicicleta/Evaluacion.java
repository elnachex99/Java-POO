import java.util.HashMap;

public class Evaluacion {
    // Mapa: NombreDueño (String) -> Bicicleta
    // El 'public' aquí es solo para seguir la imagen, normalmente sería private
    public HashMap<String, Bicicleta> clientes; 

    public Evaluacion() {
        clientes = new HashMap<>();
    }

    /**
     * Recorre la colección de clientes y llama al método parchar()
     * de cada bicicleta.
     */
    public void parcharTodas() {
        // TODO:
        for(Bicicleta b : clientes.values()){
            b.parchar();
        }
        // 1. Recorre el mapa.
        // Pista: ¿Te importan los nombres (keys) o las bicis (values)?
        // 2. A cada bici, dile .parchar()
        
    }

    /* Método para probar (No tocar) */
    public void agregarCliente(String nombre, Bicicleta bici) {
        clientes.put(nombre, bici);
    }
}