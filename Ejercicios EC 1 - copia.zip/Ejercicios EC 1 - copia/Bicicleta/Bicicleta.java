public class Bicicleta {
    private boolean estaPinchada;

    public Bicicleta() {
        this.estaPinchada = true; // Empiezan pinchadas para el test
    }

    // Este es el método que tienes que llamar desde la otra clase
    public void parchar() {
        this.estaPinchada = false;
        System.out.println("...fssshh... ¡Bici parchada!");
    }

    // Método para verificar (solo para pruebas)
    public boolean getEstaPinchada() {
        return estaPinchada;
    }
}